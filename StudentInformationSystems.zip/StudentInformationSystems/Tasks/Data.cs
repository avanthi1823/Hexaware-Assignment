﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace StudentInformationSystems
{
    internal class Data
    {
        public static void AddStudent(string firstName, string lastName, string dob, string email, string phone)
        {
            if (firstName == "" || lastName == "" || email == "")
            {
                Console.WriteLine("Invalid data. First name, last name, and email cannot be empty.");
                return;
            }

            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();
            con.Open();

            string query = "INSERT INTO Students (first_name, last_name, date_of_birth, email, phone_number) " +
                           "VALUES ('" + firstName + "', '" + lastName + "', '" + dob + "', '" + email + "', '" + phone + "')";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();

            Console.WriteLine("Student added successfully.");

            con.Close();
        }

        public static void UpdateStudentEmail(int studentId, string newEmail)
        {
            if (newEmail == "")
            {
                Console.WriteLine("Email cannot be empty.");
                return;
            }

            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();
            con.Open();

            string query = "UPDATE Students SET email = '" + newEmail + "' WHERE student_id = " + studentId;
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();

            Console.WriteLine("Email updated successfully.");

            con.Close();
        }

        public static void RecordPayment(int studentId, decimal amount, string paymentDate)
        {
            if (amount <= 0)
            {
                Console.WriteLine("Amount must be greater than 0.");
                return;
            }

            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();
            con.Open();

            string query = "INSERT INTO Payments (student_id, amount, payment_date) " +
                           "VALUES (" + studentId + ", " + amount + ", '" + paymentDate + "')";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();

            Console.WriteLine("Payment added successfully.");

            con.Close();
        }

        public static void EnrollStudent(int studentId, int courseId, string enrollDate)
        {
            if (studentId <= 0 || courseId <= 0)
            {
                Console.WriteLine("Invalid student or course ID.");
                return;
            }

            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();
            con.Open();

            string query = "INSERT INTO Enrollments (student_id, course_id, enrollment_date) " +
                           "VALUES (" + studentId + ", " + courseId + ", '" + enrollDate + "')";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();

            Console.WriteLine("Enrollment added successfully.");

            con.Close();
        }

        // Q3: Transaction Management
        public static void EnrollStudentWithPayment(int studentId, int courseId, string enrollDate, decimal amount, string paymentDate)
        {
            if (studentId <= 0 || courseId <= 0 || amount <= 0)
            {
                Console.WriteLine("Invalid input for transaction. Check student ID, course ID, or amount.");
                return;
            }

            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();
            con.Open();

            SqlTransaction transaction = con.BeginTransaction();

            string enrollQuery = "INSERT INTO Enrollments (student_id, course_id, enrollment_date) " +
                                 "VALUES (" + studentId + ", " + courseId + ", '" + enrollDate + "')";

            string payQuery = "INSERT INTO Payments (student_id, amount, payment_date) " +
                              "VALUES (" + studentId + ", " + amount + ", '" + paymentDate + "')";

            SqlCommand cmd1 = new SqlCommand(enrollQuery, con, transaction);
            SqlCommand cmd2 = new SqlCommand(payQuery, con, transaction);

            try
            {
                cmd1.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
                transaction.Commit();
                Console.WriteLine("Enrollment and payment completed successfully.");
            }
            catch
            {
                transaction.Rollback();
                Console.WriteLine("Transaction failed. Changes were rolled back.");
            }

            con.Close();
        }

        // Q4: Dynamic Query Builder
        public static void RunDynamicQuery(string table, string column, string value, string orderByColumn = "")
        {
            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();
            con.Open();

            string query = "SELECT * FROM " + table + " WHERE " + column + " = '" + value + "'";

            if (orderByColumn != "")
            {
                query += " ORDER BY " + orderByColumn;
            }

            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();

            Console.WriteLine("Results for custom query:");
            while (reader.Read())
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    Console.Write(reader.GetName(i) + ": " + reader[i].ToString() + " | ");
                }
                Console.WriteLine();
            }

            con.Close();
        }
    }
}
