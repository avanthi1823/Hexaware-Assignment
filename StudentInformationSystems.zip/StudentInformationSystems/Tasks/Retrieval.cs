﻿using StudentInformationSystems;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Task 7: Data Retrieval
namespace StudentInformationSystems
{
    public class Retrieval
    {
        // Get all students
        public static void GetAllStudents()
        {
            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();

            try
            {
                con.Open();
                string query = "select * from Students";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                bool found = false;
                while (reader.Read())
                {
                    found = true;
                    Console.WriteLine("Student ID: " + reader["student_id"] +
                                      ", Name: " + reader["first_name"] + " " + reader["last_name"]);
                }

                if (!found)
                {
                    Console.WriteLine("No students found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while fetching students: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        // Get all courses
        public static void GetAllCourses()
        {
            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();

            try
            {
                con.Open();
                string query = "select * from Courses";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                bool found = false;
                while (reader.Read())
                {
                    found = true;
                    Console.WriteLine("Course ID: " + reader["course_id"] +
                                      ", Name: " + reader["course_name"]);
                }

                if (!found)
                {
                    Console.WriteLine("No courses found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while fetching courses: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        // Get all teachers
        public static void GetAllTeachers()
        {
            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();

            try
            {
                con.Open();
                string query = "select * from Teacher";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                bool found = false;
                while (reader.Read())
                {
                    found = true;
                    Console.WriteLine("Teacher ID: " + reader["teacher_id"] +
                                      ", Name: " + reader["first_name"] + " " + reader["last_name"]);
                }

                if (!found)
                {
                    Console.WriteLine("No teachers found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while fetching teachers: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        // Get all enrollments
        public static void GetAllEnrollments()
        {
            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();

            try
            {
                con.Open();
                string query = "select * from Enrollments";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                bool found = false;
                while (reader.Read())
                {
                    found = true;
                    Console.WriteLine("Enrollment ID: " + reader["enrollment_id"] +
                                      ", Student ID: " + reader["student_id"] +
                                      ", Course ID: " + reader["course_id"]);
                }

                if (!found)
                {
                    Console.WriteLine("No enrollments found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while fetching enrollments: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        // Get all payments
        public static void GetAllPayments()
        {
            DBHandler db = new DBHandler();
            SqlConnection con = db.GetConnection();

            try
            {
                con.Open();
                string query = "select * from Payments";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                bool found = false;
                while (reader.Read())
                {
                    found = true;
                    Console.WriteLine("Payment ID: " + reader["payment_id"] +
                                      ", Student ID: " + reader["student_id"] +
                                      ", Amount: " + reader["amount"]);
                }

                if (!found)
                {
                    Console.WriteLine("No payments found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while fetching payments: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
