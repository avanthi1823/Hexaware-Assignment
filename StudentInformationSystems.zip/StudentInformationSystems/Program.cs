﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentInformationSystems
{
    class Program
    {
        static void Main(string[] args)
        {
            SIS system = new SIS();

            // Task 2
            Student student1 = new Student(1, "Arun", "Dev", "2004-01-10", "arun@gmail.com", 98765429210);
            system.Students.Add(student1);

            Course course1 = new Course(1, "Algorithms", "CS211", "Dr. Devi");
            system.Courses.Add(course1);

          
            Teacher teacher1 = new Teacher(1, "Renuka", "Suresh", "renua@college.edu");
            system.Teachers.Add(teacher1);

        
            Console.WriteLine("\nStudent Info ");
            student1.DisplayStudentInfo();
            student1.UpdateStudentInfo("Arun", "Dev", "2004-05-10", "arun@gmail.com", 9876543283);
            student1.MakePayment(5000, "2025-02-22");

            //Task 6
            system.AssignTeacherToCourse(course1, teacher1);

            //Task 3 and 6
            system.AddEnrollment(student1, course1, "2025-02-22");

            //Task 3
            Console.WriteLine("\nEnrolled Courses:");
            foreach (var c in student1.GetEnrolledCourses())
            {
                Console.WriteLine(c.CourseName);
            }

            Console.WriteLine("\nPayment History:");
            foreach (var p in student1.GetPaymentHistory())
            {
                Console.WriteLine(p.Amount + " paid on " + p.PaymentDate);
            }

            //Task 3
            Console.WriteLine("\nCourse Info ");
            course1.DisplayCourseInfo();
            course1.UpdateCourseInfo("CS211", "Datastrucutes", "Dr. Nivetha");
            Console.WriteLine("Teacher: " + course1.GetTeacher().FirstName);

            Console.WriteLine("Enrollments in Course:");
            foreach (var e in course1.GetEnrollments())
            {
                Console.WriteLine("Student ID: " + e.StudentId);
            }

           
            Console.WriteLine("\nTeacher Info ");
            teacher1.DisplayTeacherInfo();
            teacher1.UpdateTeacherInfo("RenukaSuresh", "renu@college.edu", "Algorithms");
            Console.WriteLine("Assigned Courses:");
            foreach (var c in teacher1.GetAssignedCourses())
            {
                Console.WriteLine(c.CourseName);
            }

           
            Console.WriteLine("\nEnrollment ");
            var enrollment = system.GetEnrollmentsForStudent(student1)[0];
            Console.WriteLine("Enrolled Student: " + enrollment.GetStudent().FirstName);
            Console.WriteLine("Course: " + enrollment.GetCourse().CourseName);

           
            Console.WriteLine("\nPayment ");
            var payment = student1.Payments[0];
            Console.WriteLine("Paid by: " + payment.GetStudent().FirstName);
            Console.WriteLine("Amount: Rs. " + payment.GetPaymentAmount());
            Console.WriteLine("Date: " + payment.GetPaymentDate());

            // Task 4
            Console.WriteLine("\nException Handling ");
            try
            {
                throw new StudentNotFoundException("Student with ID 999 not found.");
            }
            catch (StudentNotFoundException ex)
            {
                Console.WriteLine("Exception caught: " + ex.Message);
            }

            try
            {
                throw new InvalidCourseDataException("Course code or instructor name is invalid.");
            }
            catch (InvalidCourseDataException ex)
            {
                Console.WriteLine("Exception caught: " + ex.Message);
            }

            // Task 7 DB Connection
            Console.WriteLine("\nDB Connection ");
            DBHandler db = new DBHandler();
            db.ConnectToDatabase();

            
            Console.WriteLine("\nAll Students:");
            Retrieval.GetAllStudents();

            
            Console.WriteLine("\nAll Courses:");
            Retrieval.GetAllCourses();

            
            Console.WriteLine("\nAll Teachers:");
            Retrieval.GetAllTeachers();

           
            Console.WriteLine("\nAll Enrollments:");
            Retrieval.GetAllEnrollments();

            Console.WriteLine("\nAll Payments:");
            Retrieval.GetAllPayments();

            ////Task 8 
            //Console.WriteLine("\n Task 8: Enroll John Doe ");
            //Task_8_9_10_11.EnrollJohnDoe();

            ////Task 9 
            //Console.WriteLine("\n Task 9: Assign Teacher ");
            //Task_8_9_10_11.AssignTeacherToCourse();

            ////Task 10 
            //Console.WriteLine("\n Task 10: Payment for Jane ");
            //Task_8_9_10_11.RecordJanePayment();

            ///Task 11 
            //Console.WriteLine("\n Task 11: Enrollment Report ");
            //Task_8_9_10_11.GenerateEnrollmentReport();

            Console.ReadLine();
        }
    }
}
