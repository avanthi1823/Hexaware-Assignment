﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Task 7: Database Connectivity
namespace StudentInformationSystems
{
    public class DBHandler
    {
        string connectionString = "Server=DESKTOP-LQ66VHC;Initial Catalog=SISDB;Integrated Security=True";

        public void ConnectToDatabase()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            Console.WriteLine("\nDatbase Connection is Successful");

            con.Close();
        }

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
