﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentInformationSystems
{
    internal class SIS
    {

        public List<Student> Students;
        public List<Course> Courses;
        public List<Teacher> Teachers;
        public List<Enrollment> Enrollments;
        public List<Payment> Payments;

        public SIS()
        {
            Students = new List<Student>();
            Courses = new List<Course>();
            Teachers = new List<Teacher>();
            Enrollments = new List<Enrollment>();
            Payments = new List<Payment>();
        }


        public void AddEnrollment(Student student, Course course, string date)
        {
            Enrollment e = new Enrollment(Enrollments.Count + 1, student.StudentId, course.CourseId, date);
            e.Student = student;
            e.Course = course;
            student.Enrollments.Add(e);
            course.Enrollments.Add(e);
            Enrollments.Add(e);
        }


        public void AssignTeacherToCourse(Course course, Teacher teacher)
        {
            course.AssignedTeacher = teacher;
            teacher.AssignedCourses.Add(course);
        }


        public void RecordPayment(Student student, decimal amount, string date)
        {
            Payment p = new Payment(Payments.Count + 1, student.StudentId, amount, date);
            p.Student = student;
            student.Payments.Add(p);
            Payments.Add(p);
        }


        public List<Enrollment> GetEnrollmentsForStudent(Student student)
        {
            return student.Enrollments;
        }


        public List<Course> GetCoursesForTeacher(Teacher teacher)
        {
            return teacher.AssignedCourses;
        }


        public void EnrollStudentInCourse(Student student, Course course)
        {
            string today = DateTime.Now.ToString("yyyy-MM-dd");
            AddEnrollment(student, course, today);
            Console.WriteLine($"[SIS] {student.FirstName} enrolled in {course.CourseName}");
        }


        public void AssignTeacherToCourse(Teacher teacher, Course course)
        {
            course.AssignedTeacher = teacher;
            teacher.AssignedCourses.Add(course);
            Console.WriteLine($"[SIS] {teacher.FirstName} assigned to {course.CourseName}");
        }

        public void RecordPayment(Student student, decimal amount, DateTime paymentDate)
        {
            string date = paymentDate.ToString("yyyy-MM-dd");
            RecordPayment(student, amount, date);
            Console.WriteLine($"[SIS] Rs.{amount} recorded for {student.FirstName} on {date}");
        }

        public void GenerateEnrollmentReport(Course course)
        {
            Console.WriteLine($"\nEnrollment Report for {course.CourseName}:");
            foreach (var enrollment in course.Enrollments)
            {
                Console.WriteLine($"- Student ID: {enrollment.Student.StudentId} | Name: {enrollment.Student.FirstName} {enrollment.Student.LastName}");
            }
        }


        public void GeneratePaymentReport(Student student)
        {
            Console.WriteLine($"\nPayment Report for {student.FirstName} {student.LastName}:");
            foreach (var payment in student.Payments)
            {
                Console.WriteLine($"- Amount: Rs.{payment.Amount} | Date: {payment.PaymentDate}");
            }
        }

        public void CalculateCourseStatistics(Course course)
        {
            int enrollmentCount = 0;
            decimal totalPayment = 0;

            enrollmentCount = course.Enrollments.Count;

            foreach (var enrollment in course.Enrollments)
            {
                Student student = enrollment.Student;

                foreach (var payment in student.Payments)
                {
                    
                }
            }

            Console.WriteLine($"\nStatistics for Course: {course.CourseName}");
            Console.WriteLine("Total Enrollments: " + enrollmentCount);
            Console.WriteLine("Total Payment Collected (approx.): Rs. " + totalPayment);
        }
        public void AssignCourseToTeacher(Course course, Teacher teacher)
        {
            course.AssignedTeacher = teacher;
            teacher.AssignedCourses.Add(course);
            Console.WriteLine("Course '" + course.CourseName + "' assigned to teacher " + teacher.FirstName);
        }


        public void AddPayment(Student student, decimal amount, string paymentDate)
        {
            Payment payment = new Payment(Payments.Count + 1, student.StudentId, amount, paymentDate);
            payment.Student = student;
            student.Payments.Add(payment);
            Payments.Add(payment);
            Console.WriteLine("Payment of Rs." + amount + " added for student " + student.FirstName);
        }

    }
}

