﻿using StudentInformationSystems;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentInformationSystems { 
    public class Teacher
    {
        //Task 1
        public int TeacherId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }

        //Task 5
        public List<Course> AssignedCourses { get; set; } = new List<Course>();

        //Task 2
        public Teacher(int teacherId, string firstName, string lastName, string email)
        {
            TeacherId = teacherId;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
        }

        //Task 3
        public void UpdateTeacherInfo(string firstName, string lastName, string email)
        {
            FirstName = firstName;
            LastName = lastName;
            Email = email;
        }

        //Task 3
        public void DisplayTeacherInfo()
        {
            Console.WriteLine($"Teacher: {FirstName} {LastName}, Email: {Email}");
        }

        //Task 3
        public List<Course> GetAssignedCourses()
        {
            return AssignedCourses;
        }
    }
}
