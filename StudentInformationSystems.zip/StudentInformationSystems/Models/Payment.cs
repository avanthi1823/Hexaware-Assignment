﻿using StudentInformationSystems;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentInformationSystems
{
    public class Payment
    {
        //Task 1
        public int PaymentId { get; set; }
        public int StudentId { get; set; }
        public decimal Amount { get; set; }
        public string PaymentDate { get; set; }

        //Task 5
        public Student Student { get; set; }


        //Task 2
        public Payment(int id, int studentId, decimal amount, string date)
        {
            PaymentId = id;
            StudentId = studentId;
            Amount = amount;
            PaymentDate = date;
        }

        //Task 3
        public Student GetStudent()
        {
            return Student;
        }

        //Task 3
        public decimal GetPaymentAmount()
        {
            return Amount;
        }

        public string GetPaymentDate()
        {
            return PaymentDate;
        }
    }
}
