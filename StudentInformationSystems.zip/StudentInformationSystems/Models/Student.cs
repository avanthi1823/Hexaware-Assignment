﻿using StudentInformationSystems;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentInformationSystems
{
    public class Student
    {
        //Task 1
        public int StudentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DateOfBirth { get; set; }
        public string Email { get; set; }
        public long PhoneNumber { get; set; }

        //Task 5
        public List<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
        public List<Payment> Payments { get; set; } = new List<Payment>();

        //Task 2
        public Student(int studentId, string firstName, string lastName, String dateOfBirth, string email, long phoneNumber)
        {
            StudentId = studentId;
            FirstName = firstName;
            LastName = lastName;
            DateOfBirth = dateOfBirth;
            Email = email;
            PhoneNumber = phoneNumber;
        }

        //Task 3
        public void EnrollInCourse(Course course)
        {
            Enrollments.Add(new Enrollment(Enrollments.Count + 1, this.StudentId, course.CourseId, DateTime.Now.ToString("yyyy-MM-dd")));
        }

        //Task 3
        public void UpdateStudentInfo(string firstName, string lastName, string dob, string email, long phoneNumber)
        {
            FirstName = firstName;
            LastName = lastName;
            DateOfBirth = dob;
            Email = email;
            PhoneNumber = phoneNumber;
        }

        //Task 3
        public void MakePayment(decimal amount, string paymentDate)
        {
            Payments.Add(new Payment(Payments.Count + 1, this.StudentId, amount, paymentDate)
            {
                Student = this
            });
        }

        //Task 3
        public void DisplayStudentInfo()
        {
            Console.WriteLine($"Student: {FirstName} {LastName}, DOB: {DateOfBirth}, Email: {Email}, Phone: {PhoneNumber}");
        }


        //Task 3
        public List<Course> GetEnrolledCourses()
        {
            List<Course> courses = new List<Course>();
            foreach (var enrollment in Enrollments)
            {
                if (enrollment.Course != null)
                    courses.Add(enrollment.Course);
            }
            return courses;
        }

        //Task 3
        public List<Payment> GetPaymentHistory()
        {
            return Payments;
        }
    }
}
