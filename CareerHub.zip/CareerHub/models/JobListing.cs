﻿using System;
using System.Collections.Generic;

namespace CareerHub
{
    public class JobListing
    {
        public int JobID { get; set; }
        public int CompanyID { get; set; }
        public string JobTitle { get; set; }
        public string JobDescription { get; set; }
        public string JobLocation { get; set; }
        public decimal Salary { get; set; }
        public string JobType { get; set; }
        public DateTime PostedDate { get; set; }

        
        private List<Applicant> applicants = new List<Applicant>();

        // Allows applicants to apply for this job listing
        public void Apply(int applicantID, string coverLetter)
        {
            applicants.Add(new Applicant
            {
                ApplicantID = applicantID,
                //CoverLetter = coverLetter
            });

            Console.WriteLine($"Applicant {applicantID} applied with cover letter.");
        }

        public List<Applicant> GetApplicants()
        {
            return applicants;
        }
    }
}
