﻿//using System;
//using System.Collections.Generic;

//namespace CareerHub
//{
//    public class Company
//    {
//        public int CompanyID { get; set; }
//        public string CompanyName { get; set; }
//        public string Location { get; set; }

//        // Internal job list to store posted jobs
//        private List<JobListing> jobListings = new List<JobListing>();

//        // Allows companies to post new job openings
//        public void PostJob(string jobTitle, string jobDescription, string jobLocation, decimal salary, string jobType)
//        {
//            JobListing job = new JobListing
//            {
//                JobID = new Random().Next(1000, 9999),
//                Salary = salary,
//                JobType = jobType,

//            };

//            jobListings.Add(job);
//            Console.WriteLine($"Job '{jobTitle}' posted successfully.");
//        }

//        // Retrieves all job listings posted by this company
//        public List<JobListing> GetJobs()
//        {
//            return jobListings;
//        }
//    }
//}
//using System;
//using System.Collections.Generic;

//namespace CareerHub
//{
//    public class Company
//    {
//        public int CompanyID { get; set; }
//        public string CompanyName { get; set; }
//        public string Location { get; set; }

//        // Internal job list to store posted jobs
//        private List<JobListing> jobListings = new List<JobListing>();

//        // Allows companies to post new job openings
//        public void PostJob(string jobTitle, string jobDescription, string jobLocation, decimal salary, string jobType)
//        {
//            JobListing job = new JobListing
//            {
//                JobID = new Random().Next(1000, 9999),
//                JobTitle = jobTitle,

//                Salary = salary,
//                JobType = jobType,
//                CompanyID = this.CompanyID   // ✅ The crucial fix!
//            };

//            jobListings.Add(job);
//            Console.WriteLine($"Job '{jobTitle}' posted successfully.");
//        }

//        // Retrieves all job listings posted by this company
//        public List<JobListing> GetJobs()
//        {
//            return jobListings;
//        }
//    }
//}
using System;
using System.Collections.Generic;

namespace CareerHub
{
    public class Company
    {
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
        public string Location { get; set; }

        private List<JobListing> jobListings = new List<JobListing>();

        public void PostJob(string jobTitle, string jobDescription, string jobLocation, decimal salary, string jobType)
        {
            JobListing job = new JobListing
            {
                JobID = new Random().Next(1000, 9999),
                JobTitle = jobTitle,
                
                
                Salary = salary,
                JobType = jobType,
                CompanyID = this.CompanyID
            };

            jobListings.Add(job);
            
        }

        public List<JobListing> GetJobs()
        {
            return jobListings;
        }
    }
}
