﻿using System;

public class Applicant
{
    public int ApplicantID { get; set; }
    public string Email { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Phone { get; set; }
    public byte[] Resume { get; set; }
    public string ResumeFileName { get; set; }

    public void CreateProfile(string email, string firstName, string lastName, string phone)
    {
        if (!email.Contains("@"))
            throw new FormatException("Invalid email format.");

        Email = email;
        FirstName = firstName;
        LastName = lastName;
        Phone = phone;
    }

    public void ApplyForJob(int jobId, string coverLetter)
    {
        
    }
}
