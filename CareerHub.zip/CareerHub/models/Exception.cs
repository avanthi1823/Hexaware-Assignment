﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareerHub
{
   
       

        // Handles invalid email format during registration
        public class InvalidEmailException : System.Exception
        {
            public InvalidEmailException(string message) : base(message) { }
        }

        // Handles negative or invalid salary values
        public class NegativeSalaryException : System.Exception
        {
            public NegativeSalaryException(string message) : base(message) { }
        }

        // Handles file not found, unsupported format, etc.
        public class ResumeUploadException : System.Exception
        {
            public ResumeUploadException(string message) : base(message) { }
        }

        // Handles when application is submitted after the deadline
        public class ApplicationDeadlineException : System.Exception
        {
            public ApplicationDeadlineException(string message) : base(message) { }
        }

        // Handles database-related failures like connection or query errors
        public class DatabaseConnectionException : System.Exception
        {
            public DatabaseConnectionException(string message) : base(message) { }
        }
    }
