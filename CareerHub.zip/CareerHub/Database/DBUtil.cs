﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareerHub
{
    internal class DBUtil
    {

        public class DBHandler
        {
            string connectionString = "Server=DESKTOP-LQ66VHC;Initial Catalog=Careerhub;Integrated Security=True";

            public void ConnectToDatabase()
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                Console.WriteLine("\nDatbase Connection is Successful");

                con.Close();
            }

            public SqlConnection GetConnection()
            {
                return new SqlConnection(connectionString);
            }
        }

    }
}
