﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;

namespace CareerHub
{
    public class DatabaseManager
    {
        private List<Company> companies = new List<Company>();

        public void InitializeDatabase()
        {
            Console.WriteLine("Database initialized successfully!");
            
            companies.Add(new Company
            {
                CompanyID = 1,
                CompanyName = "Hexaware",
                Location = "Chennai"
            });
        }

        public void InsertCompany(Company company)
        {
            if (!companies.Any(c => c.CompanyName.Equals(company.CompanyName, StringComparison.OrdinalIgnoreCase)))
            {
                companies.Add(company);
                Console.WriteLine($"Company '{company.CompanyName}' inserted into the database.");
            }
            else
            {
                Console.WriteLine($"Company '{company.CompanyName}' already exists in the database.");
            }
        }

        public void InsertJobListing(JobListing job)
        {
            Console.WriteLine($"Job '{job.JobTitle}' posted by CompanyID {job.CompanyID} inserted into the database.");
        }

        public void InsertApplicant(Applicant applicant)
        {
            Console.WriteLine($"Applicant '{applicant.FirstName} {applicant.LastName}' inserted into the database.");
        }

        public void InsertJobApplication(JobApplication application)
        {
            Console.WriteLine($"Application for JobID {application.JobID} by ApplicantID {application.Applicant?.ApplicantID} inserted into the database.");
        }

        public Company GetCompanyByName(string name)
        {
            return companies.FirstOrDefault(c => c.CompanyName.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        public bool CheckCompanyExists(string name)
        {
            return companies.Any(c => c.CompanyName.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        public List<Company> GetAllCompanies()
        {
            return companies;
        }
    }
}
