﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace CareerHub
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Job Board --  Career Hub \n");

            try
            {
                DatabaseManager db = new DatabaseManager();
                db.InitializeDatabase();
                Console.WriteLine();

                string companyName = "Hexaware";
                Company company;

                if (!db.CheckCompanyExists(companyName))
                {
                    company = new Company
                    {
                        CompanyID = 1,
                        CompanyName = companyName,
                        Location = "Chennai"
                    };
                    db.InsertCompany(company);
                }
                else
                {
                    company = db.GetCompanyByName(companyName);
                    Console.WriteLine($"Company '{company.CompanyName}' already exists in the database.");
                }
                Console.WriteLine();

                var existingJobs = company.GetJobs();
                if (!existingJobs.Any(j => j.JobTitle.Equals("Software Developer", StringComparison.OrdinalIgnoreCase)))
                {
                    company.PostJob("Software Developer", "Develop enterprise-grade applications.", "Chennai", 750000, "Full-time");
                    var jobList = company.GetJobs();

                    foreach (var job in jobList)
                    {
                        if (!string.IsNullOrWhiteSpace(job.JobTitle) && job.CompanyID > 0)
                        {
                            db.InsertJobListing(job);
                            Console.WriteLine($"Job '{job.JobTitle}' posted successfully.");
                        }
                        else
                        {
                            Console.WriteLine("Error: Invalid job title or company ID.");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Job 'Software Developer' already exists for this company.");
                }
                Console.WriteLine();

                Applicant applicant = new Applicant { ApplicantID = 1001 };
                try
                {
                    applicant.CreateProfile("john.doe@email.com", "John", "Doe", "9876543210");
                    Console.WriteLine($"Applicant '{applicant.FirstName} {applicant.LastName}' created.");
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Email Format Error: " + ex.Message);
                }
                Console.WriteLine();

                string resumePath = "resume.pdf"; // Make sure this file exists in bin/Debug

                try
                {
                    UploadResume(resumePath);
                    applicant.Resume = File.ReadAllBytes(resumePath);
                    applicant.ResumeFileName = Path.GetFileName(resumePath);
                    Console.WriteLine("Resume uploaded successfully.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Resume Upload Error: " + ex.Message);
                    applicant.Resume = null;
                }
                Console.WriteLine();

                db.InsertApplicant(applicant);
                Console.WriteLine();

                var jobToApply = company.GetJobs().FirstOrDefault();
                if (jobToApply != null)
                {
                    try
                    {
                        SubmitApplication(DateTime.Now.AddDays(1));
                        applicant.ApplyForJob(jobToApply.JobID, "I'm passionate about development.");

                        foreach (var applicantInList in jobToApply.GetApplicants())
                        {
                            db.InsertJobApplication(new JobApplication
                            {
                                JobID = jobToApply.JobID,
                                Applicant = applicantInList
                            });
                        }

                        Console.WriteLine("Application submitted successfully.");
                    }
                    catch (InvalidOperationException ex)
                    {
                        Console.WriteLine("Application Error: " + ex.Message);
                    }
                }
                else
                {
                    Console.WriteLine("No job available to apply.");
                }
                Console.WriteLine();

                try
                {
                    var avgSalary = CalculateAverageSalary(company.GetJobs());
                    Console.WriteLine($"Average Salary: ₹{avgSalary}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Salary Error: " + ex.Message);
                }
                Console.WriteLine();

                ConnectToDatabase();
                Console.WriteLine();

                //Console.WriteLine("Program Completed Successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Fatal Error: " + ex.Message);
            }

            Console.ReadLine();
        }

        static void UploadResume(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("Resume file not found.");

            FileInfo file = new FileInfo(filePath);
            if (file.Length > 5 * 1024 * 1024)
                throw new Exception("File size exceeded (Max 5MB).");

            if (!file.Extension.Equals(".pdf", StringComparison.OrdinalIgnoreCase) &&
                !file.Extension.Equals(".docx", StringComparison.OrdinalIgnoreCase))
                throw new Exception("Only .pdf and .docx formats are supported.");
        }

        static void SubmitApplication(DateTime deadline)
        {
            if (DateTime.Now > deadline)
                throw new InvalidOperationException("Application deadline has passed.");
        }

        static decimal CalculateAverageSalary(List<JobListing> jobs)
        {
            if (jobs.Any(job => job.Salary < 0))
                throw new ArgumentException("Negative salary found.");

            return jobs.Average(job => job.Salary);
        }

        static void ConnectToDatabase()
        {
            bool isConnected = true;
            if (!isConnected)
                throw new Exception("Database connection failed.");
            Console.WriteLine("Database connection established.");
        }
    }
}
