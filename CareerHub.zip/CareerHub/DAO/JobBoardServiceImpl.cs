﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CareerHub
{
    internal class IJobBoardServiceImpl
    {
       

        public interface IJobBoardService
        {
            void InsertCompany(Company company);
            void InsertJobListing(JobListing job);
            void InsertApplicant(Applicant applicant);
            void InsertJobApplication(JobApplication application);
            List<JobListing> GetJobListings();
            List<Company> GetCompanies();
            List<Applicant> GetApplicants();
            List<JobApplication> GetApplicationsForJob(int jobId);
        }
    }

}

