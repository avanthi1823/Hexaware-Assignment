﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CareerHub.IJobBoardServiceImpl;

namespace CareerHub
{
    internal class IJobBoardService
    {
        
        public class JobBoardServiceImpl : IJobBoardService
        {
            public void InsertCompany(Company company) { }
            public void InsertJobListing(JobListing job) { }
            public void InsertApplicant(Applicant applicant) { }
            public void InsertJobApplication(JobApplication application) { }

            public List<JobListing> GetJobListings() => new List<JobListing>();
            public List<Company> GetCompanies() => new List<Company>();
            public List<Applicant> GetApplicants() => new List<Applicant>();
            public List<JobApplication> GetApplicationsForJob(int jobId) => new List<JobApplication>();
        }
    }

}

